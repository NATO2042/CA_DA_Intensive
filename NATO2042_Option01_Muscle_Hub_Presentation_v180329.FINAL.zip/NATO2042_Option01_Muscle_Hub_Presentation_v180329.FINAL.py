
# coding: utf-8

# # Capstone Project 1: MuscleHub AB Test

# ## Step 1: Get started with SQL

# Like most businesses, Janet keeps her data in a SQL database.  Normally, you'd download the data from her database to a csv file, and then load it into a Jupyter Notebook using Pandas.
# 
# For this project, you'll have to access SQL in a slightly different way.  You'll be using a special Codecademy library that lets you type SQL queries directly into this Jupyter notebook.  You'll have pass each SQL query as an argument to a function called `sql_query`.  Each query will return a Pandas DataFrame.  Here's an example:

# In[1]:


# This import only needs to happen once, at the beginning of the notebook
from codecademySQL import sql_query


# In[2]:


# Here's an example of a query that just displays some data
sql_query('''
SELECT *
FROM visits
LIMIT 5
''')


# In[3]:


# Here's an example where we save the data to a DataFrame
df = sql_query('''
SELECT *
FROM applications
LIMIT 5
''')


# ## Step 2: Get your dataset

# Let's get started!
# 
# Janet of MuscleHub has a SQLite database, which contains several tables that will be helpful to you in this investigation:
# - `visits` contains information about potential gym customers who have visited MuscleHub
# - `fitness_tests` contains information about potential customers in "Group A", who were given a fitness test
# - `applications` contains information about any potential customers (both "Group A" and "Group B") who filled out an application.  Not everyone in `visits` will have filled out an application.
# - `purchases` contains information about customers who purchased a membership to MuscleHub.
# 
# Use the space below to examine each table.

# In[4]:


# Examine visits here
sql_query('''
SELECT *
FROM visits
LIMIT 2;
''')

# COUNT(*) = 6000


# In[5]:


# Examine fitness_tests here
sql_query('''
SELECT *
FROM fitness_tests
LIMIT 2;
''')

# COUNT(*) = 2500


# In[6]:


# Examine applications here
sql_query('''
SELECT *
FROM applications
LIMIT 2;
''')

# COUNT(*) = 575


# In[7]:


# Examine purchases here
sql_query('''
SELECT *
FROM purchases
LIMIT 2;
''')

# COUNT(*) = 450


# We'd like to download a giant DataFrame containing all of this data.  You'll need to write a query that does the following things:
# 
# 1. Not all visits in  `visits` occurred during the A/B test.  You'll only want to pull data where `visit_date` is on or after `7-1-17`.
# 
# 2. You'll want to perform a series of `LEFT JOIN` commands to combine the four tables that we care about.  You'll need to perform the joins on `first_name`, `last_name`, and `email`.  Pull the following columns:
# 
# 
# - `visits.first_name`
# - `visits.last_name`
# - `visits.gender`
# - `visits.email`
# - `visits.visit_date`
# - `fitness_tests.fitness_test_date`
# - `applications.application_date`
# - `purchases.purchase_date`
# 
# Save the result of this query to a variable called `df`.
# 
# Hint: your result should have 5004 rows.  Does it?

# In[8]:


df = sql_query('''

SELECT 
visits.first_name, 
visits.last_name, 
visits.gender, 
visits.email, 
visits.visit_date, 
fitness_tests.fitness_test_date, 
applications.application_date,
purchases.purchase_date

FROM visits

LEFT JOIN fitness_tests
    ON visits.email = fitness_tests.email
    AND visits.first_name = fitness_tests.first_name
    AND visits.last_name = fitness_tests.last_name
    
LEFT JOIN applications
    ON visits.email = applications.email
    AND visits.first_name = applications.first_name
    AND visits.last_name = applications.last_name
    
LEFT JOIN purchases
    ON visits.email = purchases.email
    AND visits.first_name = purchases.first_name
    AND visits.last_name = purchases.last_name
    
WHERE visit_date >= "7-1-17"
''')


# ## Step 3: Investigate the A and B groups

# We have some data to work with! Import the following modules so that we can start doing analysis:
# - `import pandas as pd`
# - `from matplotlib import pyplot as plt`

# In[9]:


import pandas as pd
from matplotlib import pyplot as plt


# We're going to add some columns to `df` to help us with our analysis.
# 
# Start by adding a column called `ab_test_group`.  It should be `A` if `fitness_test_date` is not `None`, and `B` if `fitness_test_date` is `None`.

# In[10]:


df['ab_test_group'] =  df.fitness_test_date.apply(lambda x: 'A' if pd.notnull(x) else 'B')
#ALT: df['ab_test_group'] =  df.fitness_test_date.apply(lambda x: 'B' if pd.isnull(x) else 'A')

# Had a real problem is with simple logic function, I think because I couldn't get it to read the null properly/my logic form and syntax was all over the place. I could have chosen to fill the nulls in fitness_test_date with a value e.g. 'No Test' using .fillna() but I decided agaisnt it. 

#ATTEMPT 01: 
#df['ab_test_group'] = df.fitness_test_date.apply(lambda x: 'A' if x != 'None' else 'B')
#initial mistake: thought 'None' was an actual value not 'NaN'.

#ATTEMPT 02:
#df['ab_test_group'] = df.fitness_test_date.apply(lambda: 'A' if isnull() else 'B')

#ATTEMPT 03:
#2 df['ab_test_group'] = if: df.fitness_test_date.isnull() 'A' else 'B' 

print df.sample(2),'\n'
print len(df)

df.to_csv('test01_nate.csv')


# Let's do a quick sanity check that Janet split her visitors such that about half are in A and half are in B.
# 
# Start by using `groupby` to count how many users are in each `ab_test_group`.  Save the results to `ab_counts`.

# In[11]:


ab_counts = df.groupby('ab_test_group').email.count().reset_index()

print ab_counts
print type(ab_counts),'\n'

demo01_pivot = df.groupby(['ab_test_group','gender']).email.count().reset_index()
demo01_pivot = demo01_pivot.pivot(columns='gender',
                                      index='ab_test_group',
                                      values='email').reset_index()
print demo01_pivot



# We'll want to include this information in our presentation.  Let's create a pie cart using `plt.pie`.  Make sure to include:
# - Use `plt.axis('equal')` so that your pie chart looks nice
# - Add a legend labeling `A` and `B`
# - Use `autopct` to label the percentage of each group
# - Save your figure as `ab_test_pie_chart.png`

# In[12]:


plt.pie(ab_counts.email,
       autopct='%0.2f%%')

plt.axis('equal')
plt.legend(['Group A (Fitness Test)','Group B (No Fitness Test)'],
          loc=10)

plt.savefig('chart01_ab_test_pie_chart.png')
plt.show()


# ## Step 4: Who picks up an application?

# Recall that the sign-up process for MuscleHub has several steps:
# 1. Take a fitness test with a personal trainer (only Group A)
# 2. Fill out an application for the gym
# 3. Send in their payment for their first month's membership
# 
# Let's examine how many people make it to Step 2, filling out an application.
# 
# Start by creating a new column in `df` called `is_application` which is `Application` if `application_date` is not `None` and `No Application`, otherwise.

# In[13]:


df['is_application'] = df.application_date.apply(lambda x: 'No Application' if pd.isnull(x) else 'Application')

print df.sample(2)
df.to_csv('test02_nate.csv')


# Now, using `groupby`, count how many people from Group A and Group B either do or don't pick up an application.  You'll want to group by `ab_test_group` and `is_application`.  Save this new DataFrame as `app_counts`

# In[14]:


app_counts = df.groupby(['ab_test_group','is_application']).email.count().reset_index()

print app_counts 


# We're going to want to calculate the percent of people in each group who complete an application.  It's going to be much easier to do this if we pivot `app_counts` such that:
# - The `index` is `ab_test_group`
# - The `columns` are `is_application`
# Perform this pivot and save it to the variable `app_pivot`.  Remember to call `reset_index()` at the end of the pivot!

# In[15]:


app_pivot = app_counts.pivot(columns='is_application',
                                      index='ab_test_group',
                                      values='email').reset_index()

#print app_counts.iloc[:,-1]
#Is there a reason can't reference using '.iloc' e.g. app_counts.iloc[:,-1]? How would I reference a column without a name?

print app_pivot


# Define a new column called `Total`, which is the sum of `Application` and `No Application`.

# In[16]:


app_pivot['Total'] = app_pivot['Application'] + app_pivot['No Application']

print app_pivot,'\n'


# Calculate another column called `Percent with Application`, which is equal to `Application` divided by `Total`.

# In[17]:


app_pivot['Percentage with Application'] = app_pivot['Application'] / app_pivot['Total']

print app_pivot


# It looks like more people from Group B turned in an application.  Why might that be?
# 
# We need to know if this difference is statistically significant.
# 
# Choose a hypothesis tests, import it from `scipy` and perform it.  Be sure to note the p-value.
# Is this result significant?

# In[18]:


'''01 THIS STEP NEEDS TO BE REDONE -- CANT FIGURE OUT CORRECT TEST TO USE 13-03-18
INCORRECT ATTEMPTS

from scipy.stats import ttest_ind
pval = ttest_ind(app_pivot.iloc[0,-1],app_pivot.iloc[1,-1]).pvalue
print pval,'\n'

print ttest_ind(250/2254,325/2175).pvalue'''

###

'''02A RETRY: VARIOUS HYPOTHESIS TESTS 26-03-18
Numerical 01 (1 Sample T-Test): from scipy.stats import ttest_1samp
Numerical 02 (2 Sample T-Test): from scipy.stats import ttest_ind
Numerical 03 (AVONA): from scipy.stats import f_oneway
Numerical 04 (Tukey): from statsmodels.stats.multicomp import pairwise_tukeyhsd | also import AVONA
Categorial 01 (Binomial Test): from scipy.stats import binom_test
Categorial 02 (Chi Square): from scipy.stats import chi2_contingency
'''

'''02B INCORRECT Hypothesis test -- should be using Chi Square
from scipy.stats import binom_test

pval = binom_test(app_pivot.iloc[0,1], n=app_pivot.iloc[0,-2], p=app_pivot.iloc[1,-1])
print pval 

#pval1 = binom_test(250, n=2504, p=0.13000)
#print pval1

#a = app_pivot.iloc[0,1]
#b = app_pivot.iloc[0,-2]
#c = app_pivot.iloc[1,-1]
#print a
#print b
#print c

#pval2 = binom_test(a, n=b, p=c)
#print pval2'''

#CORRECT HYPOTHESIS TEST - 27/03/18
from scipy.stats import chi2_contingency

#x = [[250,2254],[325,2175]]

A_app = app_pivot.iloc[0,1]
A_noapp = app_pivot.iloc[0,2]
B_app = app_pivot.iloc[1,1]
B_noapp = app_pivot.iloc[1,2]

print A_app
print A_noapp
print B_app
print B_noapp

app_dataset = [[A_app,A_noapp],
                       [B_app,B_noapp]]

chi2, pval, dof, expected = chi2_contingency(app_dataset)
print pval
'''P value is below 0.05 so we can reject the null hypothesis (e.g. no difference between means) and conclude a significant difference DOES exist. Conversely if P > 0.05 we could conclude results where NOT statisically significant'''


# ## Step 4: Who purchases a membership?

# Of those who picked up an application, how many purchased a membership?
# 
# Let's begin by adding a column to `df` called `is_member` which is `Member` if `purchase_date` is not `None`, and `Not Member` otherwise.

# In[19]:


#Step 4 (Again?)

df['is_member'] = df.purchase_date.apply(lambda x: 'Member' if pd.notnull(x) else 'Not Member')
print df.head(3),'\n'

member_group0 = df.groupby(['is_member','ab_test_group']).email.count().reset_index()


member_group0_pivot = member_group0.pivot(columns='is_member',
                                      index='ab_test_group',
                                      values='email').reset_index()
member_group0_pivot['Total'] = member_group0_pivot['Member'] + member_group0_pivot['Not Member']
member_group0_pivot['Percentage Purchase'] = member_group0_pivot['Member'] / member_group0_pivot['Total']

print member_group0_pivot


# Now, let's create a DataFrame called `just_apps` the contains only people who picked up an application.

# In[20]:


#INCORRECT just_apps = df df.application_date.notnull().reset_index()

just_apps = df[df.is_application == 'Application']

print just_apps.head(3)
print type(just_apps)


# Great! Now, let's do a `groupby` to find out how many people in `just_apps` are and aren't members from each group.  Follow the same process that we did in Step 4, including pivoting the data.  You should end up with a DataFrame that looks like this:
# 
# |is_member|ab_test_group|Member|Not Member|Total|Percent Purchase|
# |-|-|-|-|-|-|
# |0|A|?|?|?|?|
# |1|B|?|?|?|?|
# 
# Save your final DataFrame as `member_pivot`.

# In[21]:


member_group = just_apps.groupby(['is_member','ab_test_group']).email.count().reset_index()

print member_group.head(5),'\n'

member_pivot = member_group.pivot(columns='is_member',
                                      index='ab_test_group',
                                      values='email').reset_index()

member_pivot['Total'] = member_pivot['Member'] + member_pivot['Not Member']
member_pivot['Percentage Purchase'] = member_pivot['Member'] / member_pivot['Total']

print member_pivot


# It looks like people who took the fitness test were more likely to purchase a membership **if** they picked up an application.  Why might that be?
# 
# Just like before, we need to know if this difference is statistically significant.  Choose a hypothesis tests, import it from `scipy` and perform it.  Be sure to note the p-value.
# Is this result significant?

# In[22]:


'''INCORRECT 27/03/18 - Finally realised mistake I should be using ChiSquare for my hypothesis testing in this instance, 
categorical and 2 or more samples.

from scipy.stats import binom_test

members = member_pivot.iloc[1,1]
total_applications = member_pivot.iloc[1,-2]
expected_probability = member_pivot.iloc[0,-1]

print members 
print total_applications 
print expected_probability,'\n'

pval = binom_test(members, n=total_applications, p=expected_probability)
print pval'''

#CORRECT HYPOTHESIS TEST - 27/03/18
from scipy.stats import chi2_contingency

A_appmem = member_pivot.iloc[0,1]
A_appnomem = member_pivot.iloc[0,2]
B_appmem = member_pivot.iloc[1,1]
B_appnomem = member_pivot.iloc[1,2]

print A_appmem
print A_appnomem
print B_appmem
print B_appnomem

appmem_dataset = [[A_appmem,A_appnomem],
                       [B_appmem,B_appnomem]]

#mem_dataset2 = [[200,50,250],
#               [250,75,325]]

chi2, pval, dof, expected = chi2_contingency(appmem_dataset)
print pval
'''P value > 0.05 so can conclude results are NOT statisically significant'''


# Previously, we looked at what percent of people **who picked up applications** purchased memberships.  What we really care about is what percentage of **all visitors** purchased memberships.  Return to `df` and do a `groupby` to find out how many people in `df` are and aren't members from each group.  Follow the same process that we did in Step 4, including pivoting the data.  You should end up with a DataFrame that looks like this:
# 
# |is_member|ab_test_group|Member|Not Member|Total|Percent Purchase|
# |-|-|-|-|-|-|
# |0|A|?|?|?|?|
# |1|B|?|?|?|?|
# 
# Save your final DataFrame as `final_member_pivot`.

# In[23]:


final_member_pivot = df.groupby(['is_member','ab_test_group']).email.count().reset_index()

final_member_pivot = final_member_pivot.pivot(columns='is_member',
                                      index='ab_test_group',
                                      values='email').reset_index()
#print final_member_pivot,'\n'

final_member_pivot['Total'] = final_member_pivot['Member'] + final_member_pivot['Not Member']
final_member_pivot['Percentage Purchase'] = final_member_pivot['Member'] / final_member_pivot['Total']

print 'All visitor pivot: ','\n',final_member_pivot,'\n'




# Previously, when we only considered people who had **already picked up an application**, we saw that there was no significant difference in membership between Group A and Group B.
# 
# Now, when we consider all people who **visit MuscleHub**, we see that there might be a significant different in memberships between Group A and Group B.  Perform a significance test and check.

# In[24]:


from scipy.stats import chi2_contingency

A_final_mem = final_member_pivot.iloc[0,1]
A_final_nomem = final_member_pivot.iloc[0,2]
B_final_mem = final_member_pivot.iloc[1,1]
B_final_nomem = final_member_pivot.iloc[1,2]

print A_final_mem
print A_final_nomem
print B_final_mem
print B_final_nomem

final_mem_dataset = [[A_final_mem,A_final_nomem],
                       [B_final_mem,B_final_nomem]]


chi2, pval, dof, expected = chi2_contingency(final_mem_dataset)
print 'final_member_pivot p-value: ',pval,'(P value <0.05 - result IS significant)','\n'




# ## Step 5: Summarize the acquisition funel with a chart

# We'd like to make a bar chart for Janet that shows the difference between Group A (people who were given the fitness test) and Group B (people who were not given the fitness test) at each state of the process:
# - Percent of visitors who apply
# - Percent of applicants who purchase a membership
# - Percent of visitors who purchase a membership
# 
# Create one plot for **each** of the three sets of percentages that you calculated in `app_pivot`, `member_pivot` and `final_member_pivot`.  Each plot should:
# - Label the two bars as `Fitness Test` and `No Fitness Test`
# - Make sure that the y-axis ticks are expressed as percents (i.e., `5%`)
# - Have a title

# In[25]:


'''
app_test_A = app_pivot.iloc[0,-1]
app_test_B = app_pivot.iloc[1,-1]

mem_test_A = member_pivot.iloc[0,-1]
mem_test_B = member_pivot.iloc[1,-1]

final_test_A = final_member_pivot.iloc[0,-1]
final_test_B = final_member_pivot.iloc[1,-1]
print app_test_A
print app_test_B
print mem_test_A
print mem_test_B
print final_test_A
print final_test_B
'''

from matplotlib.ticker import FuncFormatter

#from matplotlib.ticker import PercentFormatter
#ax.yaxis.set_major_formatter(PercentFormatter()) - can't work out how to display correctly

app_results = app_pivot.iloc[:,-1]
mem_results = member_pivot.iloc[:,-1]
final_results = final_member_pivot.iloc[:,-1]
ab_tests = ['Group A: Fitness Test','Group B: No Fitness Test']

print app_results
print mem_results
print final_results

####

plt.close('all')

ax = plt.subplot()
ax.yaxis.set_major_formatter(FuncFormatter(lambda y, _: '{:.1%}'.format(y))) 
#ax.set_yticks(app_results)
ax.set_ylim([0,max(app_results)+.01])

plt.bar(ab_tests,app_results, color=['C0', 'C1'])

plt.title('Percent of visitors who apply')
plt.ylabel('Application %')
plt.xlabel('Test Groups')

plt.savefig('chart02_app_results.png')
plt.show()


# In[26]:


plt.close('all')

ax = plt.subplot()
ax.yaxis.set_major_formatter(FuncFormatter(lambda y, _: '{:.1%}'.format(y))) 

plt.bar(ab_tests,mem_results, color=['#1f77b4','#ff7f0e'])

plt.title('Percent of applicants who purchase a membership')
plt.ylabel('Application Conversion %')
plt.xlabel('Test Groups')

plt.savefig('chart03_mem_results.png')
plt.show()


# In[27]:


plt.close('all')

ax = plt.subplot()
ax.yaxis.set_major_formatter(FuncFormatter(lambda y, _: '{:.1%}'.format(y))) 

bar_list = plt.bar(ab_tests,final_results)
bar_list[1].set_color('C1')

plt.title('Percent of visitors who purchase a membership')
plt.ylabel('Visitor Conversion %')
plt.xlabel('Test Groups')

plt.savefig('chart04_final_results.png')
plt.show()


# In[28]:


## FINAL ALL PLOTS IN ONE GRAPH (SUBPLOT IT)
plt.close('all')

plt.figure(figsize=(20,5))

#CHART 01 - APPLICATIONS
ax = plt.subplot(1,3,1)
ax.set_yticks(app_results)
ax.yaxis.set_major_formatter(FuncFormatter(lambda y, _: '{:.2%}'.format(y)))
plt.bar(ab_tests,app_results, color=['C0', 'C1'])

plt.title('Percent of visitors who apply')
plt.ylabel('Application %')
plt.xlabel('Test Groups')

#CHART 02 - APPLICATION CONVERSION
ax = plt.subplot(1,3,2)
ax.set_yticks(mem_results)
ax.yaxis.set_major_formatter(FuncFormatter(lambda y, _: '{:.2%}'.format(y)))
plt.bar(ab_tests,mem_results, color=['#1f77b4','#ff7f0e'])

plt.title('Percent of applicants who purchase a membership')
plt.ylabel('Application Conversion %')
plt.xlabel('Test Groups')

#CHART 03 - VISTOR CONVERSION
ax = plt.subplot(1,3,3)
ax.set_yticks(final_results)
ax.yaxis.set_major_formatter(FuncFormatter(lambda y, _: '{:.2%}'.format(y)))
bar_list = plt.bar(ab_tests,final_results)
bar_list[1].set_color('C1')

plt.title('Percent of visitors who purchase a membership')
plt.ylabel('Visitor Conversion %')
plt.xlabel('Test Groups')

plt.savefig('(not_used)_chart05_all_results.png')
plt.show()


# In[29]:


### TESTING LAST PIVOT/GRAPH but SPLIT via GENDER

demo02 = df.groupby(['ab_test_group','gender','is_member']).email.count().reset_index()
#print demo02_group,'\n'


demo02F = demo02[demo02.gender == 'female']
demo02F = demo02F.pivot(columns='is_member',
                        index='ab_test_group',
                        values='email').reset_index()
demo02F['Total'] = demo02F['Member'] + demo02F['Not Member']
demo02F['Percentage Purchase'] = demo02F['Member'] / demo02F['Total']

demo02M = demo02[demo02.gender == 'male']
demo02M = demo02M.pivot(columns='is_member',
                        index='ab_test_group',
                        values='email').reset_index()
demo02M['Total'] = demo02M['Member'] + demo02M['Not Member']
demo02M['Percentage Purchase'] = demo02M['Member'] / demo02M['Total']


print 'Female pivot: ','\n',demo02F,'\n'
print 'Male pivot: ','\n',demo02M,'\n'

###

A_demo02F_mem = demo02F.iloc[0,1]
A_demo02F_nomem = demo02F.iloc[0,2]
B_demo02F_mem = demo02F.iloc[1,1]
B_demo02F_nomem = demo02F.iloc[1,2]

print A_demo02F_mem
print A_demo02F_nomem
print B_demo02F_mem
print B_demo02F_nomem

demo02F_mem_dataset = [[A_demo02F_mem,A_demo02F_nomem],
                       [B_demo02F_mem,B_demo02F_nomem]]


chi2, pval, dof, expected = chi2_contingency(demo02F_mem_dataset)
print 'demo02F p-value: ',pval,'(P value <0.05 - result IS significant)','\n'

###

A_demo02M_mem = demo02M.iloc[0,1]
A_demo02M_nomem = demo02M.iloc[0,2]
B_demo02M_mem = demo02M.iloc[1,1]
B_demo02M_nomem = demo02M.iloc[1,2]

print A_demo02M_mem
print A_demo02M_nomem
print B_demo02M_mem
print B_demo02M_nomem

demo02M_mem_dataset = [[A_demo02M_mem,A_demo02M_nomem],
                       [B_demo02M_mem,B_demo02M_nomem]]


chi2, pval, dof, expected = chi2_contingency(demo02M_mem_dataset)
print 'demo02M p-value: ',pval,'(P value >0.05 - result IS NOT significant)','\n'

###

chi2, pval, dof, expected = chi2_contingency([demo02F_mem_dataset,demo02M_mem_dataset])
print 'TEST 1 p-value (datasets input incorrectly?): ',pval
chi2, pval, dof, expected = chi2_contingency([final_mem_dataset,demo02F_mem_dataset,demo02M_mem_dataset])
print 'TEST 2 p-value (datasets input incorrectly?): ',pval,'\n'


## FINAL ALL PLOTS IN ONE GRAPH (SUBPLOT IT)
demo02F_results = demo02F.iloc[:,-1]
demo02M_results = demo02M.iloc[:,-1]

plt.close('all')

n = 1
t = 2
d = 2
w = 0.8
demo02F_x = [t*element + w*n for element
             in range(d)]

plt.bar(demo02F_x,demo02F_results)

n = 2
t = 2
d = 2
w = 0.8
demo02M_x = [t*element + w*n for element
             in range(d)]

plt.bar(demo02M_x,demo02M_results)


ax = plt.subplot()
ax.yaxis.set_major_formatter(FuncFormatter(lambda y, _: '{:.2%}'.format(y)))
#ax.set_xticks(range(5))
#ax.set_xticklabels(['Group A: Fitness Test (F)','Group B: No Fitness Test (F)','Group A: Fitness Test (M)','Group B: No Fitness Test (M)'])


plt.title('Percent of visitors who purchase a membership via Gender')
plt.ylabel('Visitor Conversion %')
plt.xlabel('Test Groups')

plt.savefig('(not_used)_chart06A_all_results_male_v_female.png')
plt.show()

###

